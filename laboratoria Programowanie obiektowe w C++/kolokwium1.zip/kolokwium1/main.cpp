#include <iostream>
#include <string>
#include <cmath>
#include <figura.h>
using namespace std;

void porownajTrojkaty(Trojkat* t1,Trojkat* t2){
    double polet1=t1->obliczPole();
    double polet2=t2->obliczPole();
    if (polet1>polet2){
        cout<<"pole "<<t1->getNazwa()<<" jest wieksze"<<endl;
    cout<<"typ: "<<t1->getTypTrojkata()<<endl;
    }
    if (polet2>polet1){
        cout<<"pole "<<t2->getNazwa()<<" jest wieksze"<<endl;
    cout<<"typ: "<<t2->getTypTrojkata()<<endl;
    }
    else{
        cout<<"sa rowne"<<endl;
    }
}
int main()
{
    Trojkat t1("T1",4,5,"Prostokatny");
    t1.wyswietlInformacje();
    Trojkat t2("T2",4,6,"Prostokatny");
    t2.wyswietlInformacje();
    porownajTrojkaty(&t1,&t2);
    return 0;
}

#ifndef FIGURA_H
#define FIGURA_H
#include <string>
using namespace std;
class Figura
{
private:
    string nazwa;
public:
    Figura(string nazwa);
    string getNazwa()const;
    void setNazwa(string nazwa);
};
class Trojkat: public Figura{
private:
    double dlugoscPodstawy,dlugoscWysokosci;
    string TypTrojkata;
public:
    Trojkat(string nazwa,double dlugoscPodstawy,double dlugoscWysokosci,string TypTrojkata);
    double obliczPole() const;
    string getTypTrojkata()const;
    double getPodstawa() const;
    double getWysokosc() const;
    void setPodstawa(double podstawa);
    void setWysokosc(double wysokosc);
    void setTypTrojkata(string TypTrojkata);
    void wyswietlInformacje() const;
};

#endif // FIGURA_H

#include "figura.h"
#include <iostream>
using namespace std;
Figura::Figura(string nazwa){
    this->nazwa =nazwa;

}
string Figura::getNazwa()const{
    return nazwa;
}
void Figura::setNazwa(string nazwa){
    this->nazwa=nazwa;
}
Trojkat::Trojkat(string nazwa, double dlugoscPodstawy, double dlugoscWysokosci,string TypTrojkata)
    :Figura(nazwa),dlugoscPodstawy(dlugoscPodstawy),dlugoscWysokosci(dlugoscWysokosci),TypTrojkata(TypTrojkata){}
double Trojkat::obliczPole()const{
    return 0.5*dlugoscPodstawy*dlugoscWysokosci;
}
string Trojkat::getTypTrojkata()const{
    return TypTrojkata;
}
double Trojkat::getPodstawa()const{
    return dlugoscPodstawy;
}
double Trojkat::getWysokosc()const{
    return dlugoscWysokosci;
}

void Trojkat::setPodstawa(double dlugoscPodstawy){
    this->dlugoscPodstawy=dlugoscPodstawy;
}
void Trojkat::setWysokosc(double dlugoscWysokosci){
    this->dlugoscWysokosci=dlugoscWysokosci;
}
void Trojkat::setTypTrojkata(string TypTrojkata){
    this->TypTrojkata=TypTrojkata;
}
void Trojkat::wyswietlInformacje()const {
    cout<< "Nazwa figury: "<<getNazwa()<<endl;
    cout<<"Dlugocs podstawy: "<< dlugoscPodstawy<<endl;
    cout<<"Wysokosc figury: "<<dlugoscWysokosci<<endl;
    cout<<"typ trojkata: "<<TypTrojkata<<endl;
    cout<<"pole trojkata: "<<obliczPole()<<endl;
}

import math
while True:
    try:
        print("ax^2+bx+c=0")
        a = int(input("podaj a: "))
        b = int(input("podaj b: "))
        c = int(input("podaj c: "))
        delta = b**2 - 4*a*c
        print("delta = ", delta)
    except ValueError:
        print("to nie jest liczba calkowita")
    else:
        break
if  delta == 0:
    x0 = (-b) / (2 * a)
    print(x0)
elif delta > 0:
    x1 = (-b - math.sqrt(delta)) / 2 * a
    x2 = (-b + math.sqrt(delta)) / 2 * a
    print("pierwsze miejsce zerowe = ",x1,", drugie miejsce zerowe = ",x2 )
elif delta < 0:
    print("brak pierwiastkow")
    input("enter to exit")


while True:
    try:

        liczba = int(input("wybierz liczbe od 0-999: "))
        if liczba >= 1000 or liczba < 0 :
            print("zly przedzial")

    except ValueError:
        print("to nie jest liczba calkowita")
        continue
    else:
        setki = int(liczba/100)
        dziesiatki = int((liczba - (setki*100))/10 )
        jednosci = int(liczba - (setki*100) - (dziesiatki*10))

        print("setki: ", setki, " dziesiatki: ", dziesiatki," jednosci: ", jednosci)
        suma= setki+dziesiatki+jednosci
        print("suma: ", suma)
        input("enter to exit")
        break

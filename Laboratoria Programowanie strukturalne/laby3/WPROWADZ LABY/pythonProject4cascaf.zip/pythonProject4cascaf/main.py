
while True:
    try:
        odp1 = int(input("podaj symbol graczu nr 1 0= papier, 1=nozyce, 2=kamien: "))
    except ValueError:
        print("podaj liczbe graczu nr 1")
        continue
    else:
        break

while True:
    try:
        odp2 = int(input("podaj symbol graczu nr 2 0= papier, 1=nozyce, 2=kamien: "))
    except ValueError:
        print("podaj liczbe graczu nr 2")
        continue
    else:
        pass

if -1 < (odp1) < 3 and -1 < (odp2) < 3:
    pass
if 3 < odp1 or odp1 < -1 or odp2 < -1 or 3 < odp2:
    print("niepoprawne dane ")
if odp1==odp2:
    print("remis")
    input("enter to exit")
if odp1 == 0 and odp2 == 2:
    print("wygrywa gr1")
    input("enter to exit")
if odp1 > 0 and odp2 > odp1:
    print("wygrywa 2")
    input("enter to exit")
if odp1 == 1 and odp2 == 0:
    print("wygrywa gr1")
    input("enter to exit")
if odp2 == 1 and odp1 == 0:
    print("wygrywa gr2")
    input("enter to exit")
if odp1 == 2 and odp2 == 1:
    print("wygrywa gr1")
    input("enter to exit")
if odp2 == 2 and odp1 == 1:
    print("wygrywa gr2")
    input("enter to exit")
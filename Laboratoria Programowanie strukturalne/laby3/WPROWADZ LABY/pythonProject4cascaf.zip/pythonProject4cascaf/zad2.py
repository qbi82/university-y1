while True:
    try:
        liczb1 = int(input("podaj pierwsza liczbe: "))
        liczb2 = int(input("podaj druga liczbe: "))
        liczb3 = int(input("podaj trzecia liczbe: "))
        pass
    except ValueError:
        print("to nie jest liczba calkowita")
        continue
    else:

if (liczb1 >= liczb2) and (liczb1 >= liczb3):
    najw = liczb1
elif (liczb2 >= liczb1) and (liczb2 >= liczb3):
    najw = liczb2
elif (liczb3 >= liczb2) and (liczb3 >= liczb1):
    najw = liczb3
print("najwieksza liczba to: ", najw)
input("enter to exit")